'use client';

import { useState } from 'react';

export default function Home() {
  const [ingredients, setIngredients] = useState('');
    const [recipe, setRecipe] = useState('');
      const [loading, setLoading] = useState(false);

        const handleGenerate = async () => {
            if (!ingredients) return;
                setLoading(true);
                    setRecipe(''); // Clear previous recipe

                        try {
                              const res = await fetch('/api/generate', {
                                      method: 'POST',
                                              headers: { 'Content-Type': 'application/json' },
                                                      body: JSON.stringify({ ingredients }),
                                                            });

                                                                  const data = await res.json();
                                                                        if (data.recipe) {
                                                                                setRecipe(data.recipe);
                                                                                      } else {
                                                                                              alert('Could not generate recipe. Check your API key.');
                                                                                                    }
                                                                                                        } catch (e) {
                                                                                                              alert('Error connecting to server.');
                                                                                                                  } finally {
                                                                                                                        setLoading(false);
                                                                                                                            }
                                                                                                                              };

                                                                                                                                return (
                                                                                                                                    <div style={{ padding: '20px', maxWidth: '600px', margin: '0 auto', fontFamily: 'sans-serif' }}>
                                                                                                                                          <h1 style={{ textAlign: 'center' }}>👨‍🍳 Mobile AI Chef</h1>
                                                                                                                                                
                                                                                                                                                      <p>List your ingredients below (separated by commas):</p>
                                                                                                                                                            
                                                                                                                                                                  <textarea
                                                                                                                                                                          value={ingredients}
                                                                                                                                                                                  onChange={(e) => setIngredients(e.target.value)}
                                                                                                                                                                                          placeholder="e.g. chicken, rice, tomato, onion"
                                                                                                                                                                                                  style={{ width: '100%', padding: '10px', height: '100px', fontSize: '16px', borderRadius: '8px', border: '1px solid #ccc' }}
                                                                                                                                                                                                        />
                                                                                                                                                                                                              
                                                                                                                                                                                                                    <button 
                                                                                                                                                                                                                            onClick={handleGenerate} 
                                                                                                                                                                                                                                    disabled={loading}
                                                                                                                                                                                                                                            style={{ 
                                                                                                                                                                                                                                                      width: '100%', 
                                                                                                                                                                                                                                                                padding: '15px', 
                                                                                                                                                                                                                                                                          marginTop: '10px', 
                                                                                                                                                                                                                                                                                    backgroundColor: loading ? '#ccc' : '#0070f3', 
                                                                                                                                                                                                                                                                                              color: 'white', 
                                                                                                                                                                                                                                                                                                        border: 'none', 
                                                                                                                                                                                                                                                                                                                  borderRadius: '8px', 
                                                                                                                                                                                                                                                                                                                            fontSize: '18px',
                                                                                                                                                                                                                                                                                                                                      fontWeight: 'bold'
                                                                                                                                                                                                                                                                                                                                              }}
                                                                                                                                                                                                                                                                                                                                                    >
                                                                                                                                                                                                                                                                                                                                                            {loading ? 'Generating Recipe...' : 'Get Recipe'}
                                                                                                                                                                                                                                                                                                                                                                  </button>

                                                                                                                                                                                                                                                                                                                                                                        {recipe && (
                                                                                                                                                                                                                                                                                                                                                                                <div style={{ marginTop: '30px', background: '#f5f5f5', padding: '20px', borderRadius: '10px', whiteSpace: 'pre-wrap' }}>
                                                                                                                                                                                                                                                                                                                                                                                          {recipe}
                                                                                                                                                                                                                                                                                                                                                                                                  </div>
                                                                                                                                                                                                                                                                                                                                                                                                        )}
                                                                                                                                                                                                                                                                                                                                                                                                            </div>
                                                                                                                                                                                                                                                                                                                                                                                                              );
                                                                                                                                                                                                                                                                                                                                                                                                              }