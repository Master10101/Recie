import { NextResponse } from 'next/server';
import OpenAI from 'openai';

// This connects to OpenAI using the key we will set later in Vercel
const openai = new OpenAI({
  apiKey: process.env.OPENAI_API_KEY,
  });

  export async function POST(req: Request) {
    try {
        const { ingredients } = await req.json();

            if (!ingredients) {
                  return NextResponse.json({ error: 'Ingredients are required' }, { status: 400 });
                      }

                          // This is the instruction we send to the AI
                              const prompt = `
                                    I have these ingredients: ${ingredients}.
                                          Create a detailed recipe using these ingredients. Assume I have basic pantry items like salt, oil, and water.
                                                Format the response with a clear Title, Ingredients list, and Step-by-Step instructions.
                                                    `;

                                                        const completion = await openai.chat.completions.create({
                                                              model: "gpt-3.5-turbo",
                                                                    messages: [{ role: "user", content: prompt }],
                                                                        });

                                                                            return NextResponse.json({ recipe: completion.choices[0].message.content });
                                                                              } catch (error) {
                                                                                  console.error('Error:', error);
                                                                                      return NextResponse.json({ error: 'Failed to generate recipe' }, { status: 500 });
                                                                                        }
                                                                                        }